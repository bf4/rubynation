require "rspec"
require File.join(File.dirname(__FILE__), "../lib/rubynation.rb")